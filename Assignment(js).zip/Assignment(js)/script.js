

// Merge two array and remove the duplicate elements from the merged array.
// function merger(a,b){
 
//  let c = a.concat(b)
//  let d = new Set(c)
//   return Array.from(d)


// }
// console.log(merger([2,4,6],[3,4,6]))



// Remove an object from an array of objects. [ Do this using filter method and you have to create the array of objects ]
// let arrayOfObject = [
//     {
//         name: "rahim",
//         age: 23,
//         color: "brown"
//     },
//     {
//         name: "Jon Doe",
//         age: 33,
//         color: "white"
//     },
//     {
//         name: "Mike Tyson",
//         age: 55,
//         color: "black"
//     },
//     {
//         name: "Kabin",
//         age: 13,
//         color: "white"
//     }
// ]


// const verify = arrayOfObject.filter((currentVal, index, arr) => {
//     return currentVal.age > 13
// })
// console.log(verify)


// fibonnaci sequence

// function fibonnaci(n) {
//     let number = []
  
//       if(n === 0){
//         return number = [0]
//       } else if(n === 1){
//         return number = [1]
//       }else{
//         number = [0,1]
//         for (let i = 2; i < n; i++){
//             number.push(number[number.length-2] + number[number.length-1])
        
//         }
//       }
  
    
//     return number
//   }
//   console.log(fibonnaci(10))



